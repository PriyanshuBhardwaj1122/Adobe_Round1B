"""Utility functions for text processing and other helpers."""

__all__ = []