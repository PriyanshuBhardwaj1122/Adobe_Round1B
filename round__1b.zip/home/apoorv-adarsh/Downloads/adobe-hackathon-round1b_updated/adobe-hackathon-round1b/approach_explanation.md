# Approach Explanation – Adobe Hackathon Round 1B

This document outlines the methodology used to build our persona‑driven document intelligence system.  The aim is to extract and prioritise the most relevant sections from multiple PDFs given a persona (role and expertise) and a job‑to‑be‑done (task description) while adhering to strict performance constraints: CPU‑only execution, ≤ 1 GB model size and ≤ 60 seconds total processing time for up to 5 documents.

## PDF Processing

We chose to convert PDFs to plain text using the `pdftotext` utility from the Poppler suite.  Poppler is lightweight, widely available on Linux and does not require external network access.  The `pdfinfo` tool extracts the page count, after which `pdftotext` is invoked for each page separately.  Page‑wise conversion allows us to preserve page numbers in downstream analysis.

To derive a document outline, we apply simple heuristics on the extracted lines:

1. **Heading detection** – Lines shorter than 100 characters with fewer than 15 words are considered headings if most words are title‑cased (first letter capitalised), entirely uppercase, or begin with enumeration patterns (e.g. “1.” or “2.1”).
2. **Section aggregation** – When a heading is detected, the subsequent lines are aggregated until the next heading.  Each resulting section stores the heading text, concatenated content and the page number on which it appears.  If no headings are found on a page, the entire page is treated as a single section with the title “Page N”.

This heuristic approach is deliberately lightweight.  It avoids heavy font‑metric analysis and performs well on diverse document layouts, though it may misclassify some headings.  More precise detection could be achieved by analysing font sizes via libraries such as PyMuPDF, but that would increase complexity and runtime.

## Content Analysis & Relevance Scoring

To match sections against the persona and job description we build a multi‑factor relevance score:

1. **Semantic similarity (40 %)** – The core signal is the cosine similarity between a TF‑IDF vector of each section’s text and a query vector derived from the persona’s role/description and the job‑to‑be‑done.  We use scikit‑learn’s `TfidfVectorizer` with English stopword removal.  This representation is compact and well suited for small corpora.
2. **Persona match (25 %)** – We compute the fraction of unique words from the persona’s role that also appear in the section.  This boosts sections that explicitly mention the expertise area (e.g. “neural networks” for a PhD researcher in computational biology).
3. **Actionability (20 %)** – A small set of action verbs (create, analyse, design, build, optimise, evaluate, identify, summarise, implement, etc.) is used to estimate how actionable a section is.  The score is the ratio of these verbs to the total word count in the section.
4. **Cross‑document importance (15 %)** – We count how many documents share the same section title.  Repeated headings (such as “Conclusion” or “Abstract”) often contain universally relevant information.  The frequency is normalised across the corpus and contributes a modest boost.

The final relevance score is a weighted sum of these four components.  Sections are sorted by descending score and assigned an `importance_rank` starting at 1.

## Sub‑Section Refinement & Synthesis

After ranking, the top sections (by default the top five) undergo a finer grained analysis.  Each section is split into sentences using punctuation.  We then select the two sentences with the highest overlap of terms from the persona and job description.  This naive extractive summarisation preserves key information and reduces noise without requiring a large language model.  The selected sentences are concatenated to form the `refined_text` for the sub‑section analysis.

Although the cross‑document synthesis in this implementation is minimal, the architecture leaves room for expansion.  Future improvements could build knowledge graphs, detect contradictions between documents or perform topic clustering to identify complementary information.  Quantised transformer models (≤ 1 GB) or more advanced summarisation algorithms could replace TF‑IDF and simple sentence overlap while still running entirely on the CPU.

## Performance & Constraint Handling

The entire pipeline operates offline and on CPU.  `pdftotext` is highly performant and the TF‑IDF vectoriser scales linearly with the number of sections.  Memory usage remains modest since we process documents sequentially and use sparse matrices for similarity computations.  No third‑party network calls are made and all models fit comfortably within the 1 GB limit.