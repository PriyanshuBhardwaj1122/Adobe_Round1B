# Adobe Hackathon Round&nbsp;1B – Persona‑Driven Document Intelligence

## Overview

This repository contains a reference implementation for the **Round 1B** task of Adobe’s “Connecting the Dots” hackathon.  The goal of this round is to transform a collection of related PDFs into a personalised knowledge base.  Given a **persona** (role description) and a **job‑to‑be‑done** (task description), the system must identify the most relevant sections across multiple documents, rank them by importance, and provide a refined sub‑section summary.  The entire solution executes offline using only CPU resources and complies with the strict memory and time constraints defined in the challenge.

## Architecture

The solution is organised into a modular pipeline (see `src/`).  Each module has a single responsibility and can be tested independently.  A high‑level overview follows:

1. **PDF Processing (`src/pdf_processor.py`)** – Uses the `pdftotext` tool from `poppler-utils` to convert each page of a PDF into text.  Lightweight heuristics detect candidate headings (short, title‑cased lines or enumerated items) and group the following paragraphs into sections, capturing both the section title and page number.

2. **Content Analysis (`src/content_analyzer.py`)** – Builds TF‑IDF vectors across all extracted sections and a composite query derived from the persona and job description using a hand‑rolled implementation (no external libraries required).  It then computes cosine similarity, simple persona‑term overlap and an actionability measure based on a small list of action verbs.  A cross‑document importance term encourages alignment of repeated headings across files.  These factors are combined into a single relevance score per section.

3. **Persona Matching (`src/persona_matcher.py`)** – Exposes the ranking functionality.  Given a list of section dictionaries, persona and job information, it produces a sorted list with an `importance_rank` field.

4. **Multi‑Document Intelligence (`src/document_intelligence.py`)** – Performs basic cross‑document synthesis and sub‑section refinement.  The top ranked sections are summarised by selecting the most query‑relevant sentences using term overlap with the persona and job description.

5. **Main Entrypoint (`src/main.py`)** – Discovers input JSON files in the `/app/input` directory, orchestrates parsing and analysis for each document collection, and writes a properly formatted output JSON to `/app/output`.  Metadata such as the processing timestamp are included.

## Installation & Setup

The project is designed to run inside a Docker container on an AMD64 machine with no network access.  To build the image and run the solution:

```bash
# Build the Docker image
docker build --platform linux/amd64 -t persona-intelligence:latest ./adobe-hackathon-round1b

# Run the container (mounting input and output directories)
docker run --rm -v $(pwd)/input:/app/input -v $(pwd)/output:/app/output --network none persona-intelligence:latest
```

Place your input JSON file and corresponding PDFs into the `input/` directory.  The container will process all `*.json` files in this directory and write `*.json` results into the `output/` directory.

## Usage

Each input JSON must follow the structure specified by the hackathon:

```json
{
  "challenge_info": {"challenge_id": "string", "test_case_name": "string", "description": "string"},
  "documents": [
    {"filename": "document1.pdf", "title": "Document Title"},
    {"filename": "document2.pdf", "title": "Another Title"}
  ],
  "persona": {"role": "Professional Role", "description": "Optional description"},
  "job_to_be_done": {"task": "Specific detailed task description"}
}
```

The output JSON will match the required schema:

```json
{
  "metadata": {
    "input_documents": ["document1.pdf", "document2.pdf"],
    "persona": "Role description",
    "job_to_be_done": "Task description",
    "processing_timestamp": "2025-07-18T15:34:56.502"
  },
  "extracted_sections": [
    {
      "document": "document1.pdf",
      "section_title": "Introduction",
      "importance_rank": 1,
      "page_number": 3
    },
    ...
  ],
  "subsection_analysis": [
    {
      "document": "document1.pdf",
      "refined_text": "Concise summary of the most relevant sentences in the section.",
      "page_number": 3
    },
    ...
  ]
}
```

## Performance

    The implementation uses only CPU resources and keeps the memory footprint low by working with plain text and TF‑IDF vectors.  No external network calls are made.  Parsing is performed via `pdftotext`, which is lightweight and well suited for command‑line use in constrained environments.  TF‑IDF is computed using a simple custom implementation, avoiding the need for heavy machine‑learning libraries.

## Technical Details

For an in‑depth explanation of the algorithms, design decisions and heuristics, see the [`approach_explanation.md`](approach_explanation.md) file.

## Future Enhancements

- **Better heading detection** – The current heuristics are intentionally simple.  Integrating font metrics from PDF parsing (e.g. using PyMuPDF) would improve detection of H1/H2/H3 headings.
- **Semantic models** – Offline sentence embeddings (e.g. DistilBERT or MiniLM) could replace TF‑IDF for deeper semantic similarity without internet access.  Quantised models (<1 GB) can be loaded with `transformers` if packaged in the `models/` directory.
- **Cross‑document reasoning** – More advanced knowledge graph construction and contradiction detection could be added to the synthesis engine.
- **Multilingual support** – Additional stopword lists and basic stemming could improve handling of non‑English documents.